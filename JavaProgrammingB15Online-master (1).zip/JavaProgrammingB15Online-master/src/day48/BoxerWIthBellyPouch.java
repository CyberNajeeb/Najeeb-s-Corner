package day48;

public interface BoxerWIthBellyPouch {

    public abstract void kickBox();

    public abstract void carryChildInThePocket();

}
