package day48;

public abstract class Animal {

    public abstract void makeNoise();

}
