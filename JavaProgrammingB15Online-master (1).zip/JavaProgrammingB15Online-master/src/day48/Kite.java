package day48;

public class Kite implements Flyable {

    @Override
    public void fly() {
        System.out.println("Kite fly in the wind");
    }

}
