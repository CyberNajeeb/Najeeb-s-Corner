package day48;

public class Superman implements Flyable {


    @Override
    public void fly() {
        System.out.println("Super man fly using super power");
    }
}
