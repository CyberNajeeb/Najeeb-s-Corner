package day09;

public class InitializingAVariable {

    public static void main(String[] args) {

//        int num ;

// a variable inside a method, must get initial value
// before it's being used for the first time
        // and there should not be any chance
        // this variable does not get value before usage
        //      System.out.println(num);
        String name = "";

        //System.out.println(name);


    }

}
