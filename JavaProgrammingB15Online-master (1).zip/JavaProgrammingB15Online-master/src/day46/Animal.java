package day46;

public class Animal {


    public void speak() {

        System.out.println("Animal speak");
    }

}