package day02;

public class VariableIntro {


    // This is where any program will start running
    // a program will run from the first statement inside main method till last statement inside main method
    public static void main(String[] args) {

        // int is one of the data type to store whole number
        int offerCnt = 3;
        int corollaMileage;
        corollaMileage = 5000;

        int TVsize = 67;
        // Names in Java is extremely Case Sensitive !!!!!!!!!!!
        //System.out.println( tvsize  );


        System.out.println(offerCnt);
        System.out.println(corollaMileage);


        // TASK 1 :
        // name your favorite number
        // name your classmate count
        int favoritenumber = 100;
        int Favoritenumber = 100;
//        int FavoriteNumber = 100 ;
        int Favorite_number = 100;

        //  int Favoritenumber = 100 ; Variable name can not be reused!!!!!!!


        int nextnumnberfrom9 = 10;
        int populationofbattch15now = 300;

        //  int 9to5 = 95 ;  // NUMBER CANNOT COME FIRST IN ANY NAME !!

        int my$FolderCount = 6;
        my$FolderCount = 10;


        my$FolderCount = 100;

        System.out.println(my$FolderCount);

        //int my$FolderCount =  6 ;


        //System.out.println( nextnumnberfrom9 );


    }


}
