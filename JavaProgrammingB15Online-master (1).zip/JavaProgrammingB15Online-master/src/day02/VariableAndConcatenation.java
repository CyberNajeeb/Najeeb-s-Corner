package day02;

public class VariableAndConcatenation {

    public static void main(String[] args) {


        int hourOfCoding = 10;

        // System.out.println( hourOfCoding  );

        // Concatenation is combining two piece of information

        System.out.println("The hour of Coding is   " + hourOfCoding);

        // create a variable for your birth year
        // create a variable for your age
        // create a variable for your family member count
        // create a variable for monitor count
        // create a variable for area code
        // create a variable for desired salary
        // print them in this format
        ///  my birth year is :  yourBirthYearVariable
        ///  and so on

        int birthYear = 1995;
        int myAge = 23;
        int familyMemberCount = 3;
        int monitorNumber = 2;
        int areaCode = 77054;
        int desiredSalary = 300000;

        System.out.println("My birth year is " + birthYear);
        System.out.println("My age is " + myAge);
        System.out.println("My family member count is " + familyMemberCount);
        System.out.println("My monitor count is " + monitorNumber);
        System.out.println("My area code is " + areaCode);
        System.out.println("my desired salary is " + desiredSalary);


    }


}
