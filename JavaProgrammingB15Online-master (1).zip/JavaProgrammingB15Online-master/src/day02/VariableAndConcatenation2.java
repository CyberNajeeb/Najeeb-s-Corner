package day02;

public class VariableAndConcatenation2 {

    public static void main(String[] args) {


        int birthYear = 1987;
        int age = 32;


        System.out.println("My birth year is " + birthYear);
        System.out.println("My age  is " + age);


        System.out.println("My birth year is " + birthYear + "  My Age is " + age);

    }


}
