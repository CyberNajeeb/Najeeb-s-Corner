package day02;

public class AboutMe {


    public static void main(String[] arg) {


        // main method is the starting point of the program

        System.out.println("My Name is Akbar");
        System.out.println("I am your Instructor for the course");
        System.out.println("I love Java");


    }


}
