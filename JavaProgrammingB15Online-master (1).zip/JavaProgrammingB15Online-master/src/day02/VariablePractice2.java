package day02;

public class VariablePractice2 {

    public static void main(String[] args) {


        System.out.println("MY PROGRAM STARTED ");

        int my$FolderCount = 6;

        my$FolderCount = 10;

        System.out.println(my$FolderCount);

        my$FolderCount = 100;

        System.out.println(my$FolderCount);


    }


}
