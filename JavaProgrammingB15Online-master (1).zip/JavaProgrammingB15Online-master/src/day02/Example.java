package day02;

public class Example {


    public static void main(String[] args) {


    }


}
