package day51.polymorphism;

public interface Drawable {

    void drawTheThing();

}
