package day49;

public interface Autonomous {

    void selfDrive();

}
