package day49;

public class Main {


    public static void main(String[] args) {

        // calling interface static method
        // we can use static way
        // interfaceName.staticMemberName
        // no implementing needed!!!!
        Juicy.squeeze();


    }


}
