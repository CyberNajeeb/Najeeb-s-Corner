package day07;

public class IntroToIfElseStatement {


    public static void main(String[] args) {

        int score = 79;
        //if( PUT YOUR CONDITION HERE ) {
        //     do this if the condition is true
        // } else {
        //      do this if it is not true
        // }

        if (score > 60) {
            System.out.println(" CHOCOLATE FOR YOU !!");
        } else {
            System.out.println("  Try harder next time !! not tv , no phone , DO NOT GIVE UP ");
        }

        System.out.println("THE END ");


    }


}
