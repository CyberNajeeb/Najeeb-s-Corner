package day07;

public class IntroToIfStatement {


    public static void main(String[] args) {


        int score = 59;

        //if( PUT YOUR CONDITION HERE ) {
        //
        //do this if the condition is true

        // }

        System.out.println(score > 60);

        if (score > 60) {

            System.out.println(" CHOCOLATE FOR YOU !!");

        }

        System.out.println("THE END ");


    }


}
