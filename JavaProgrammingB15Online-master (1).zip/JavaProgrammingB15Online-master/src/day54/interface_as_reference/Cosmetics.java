package day54.interface_as_reference;

public interface Cosmetics {

}
