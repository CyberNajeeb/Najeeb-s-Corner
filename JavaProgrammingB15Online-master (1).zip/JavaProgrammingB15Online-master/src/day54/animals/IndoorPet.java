package day54.animals;

public interface IndoorPet {
    public abstract void play();
}


