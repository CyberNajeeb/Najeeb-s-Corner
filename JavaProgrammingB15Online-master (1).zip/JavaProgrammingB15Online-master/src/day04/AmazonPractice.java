package day04;

public class AmazonPractice {
//        String productName  Amazon Fire
//        String  model     HD
//        int   version         8
//        float price          79.99
//
//        I saw Fire HD8 hands-free with Alexa for $79.99\

    public static void main(String[] args) {


        String productName = "Fire";
        String model = "HD";
        int version = 8;
        float price = 79.99f;

        System.out.println("I saw " + productName + " " + model + version + " hands-free with Alexa for " + price);


    }

}
