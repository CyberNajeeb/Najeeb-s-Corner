package day04;

public class FahrenheitToCelcius {


    public static void main(String[] args) {


        double fahrenheit = 78;
        double celsius;

        celsius = (5.0 / 9) * (fahrenheit - 32);

        System.out.println(fahrenheit + "F equals to " + celsius + "C.");


    }


}
