package day04;

public class StringPractice {

    public static void main(String[] args) {

        String firstName = "Muge";
        String lastName = "Kir";
//a.qewkjsdjksdfajkhfdsajkfshl;lskhj
        String fullName = firstName + "\t" + lastName;

        System.out.println("my first name is " + firstName);
        System.out.println("my last name is  " + lastName);

        System.out.println("my full name is " + fullName);

    }

}
