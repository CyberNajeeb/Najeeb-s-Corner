package day01;    // this is saying your class is under this folder , it's called package in java

// Class is the most fundemental building block of your source code
public class Main {


    // This is the place you program start running
    public static void main(String[] args) {
        // This is called comment and it always start with double slash
        // and compiler will IGNORE THIS !!!!
        //I am gonna say hello
        // JAVA IS CASE SENSITIVE LANGUAGE
        // System and system are very different thing in java
        // Hello AND hello are different for java
        System.out.println("Hello Batch 15");
        //       System.out.println("I am still here");
        System.out.println("I love Java");

        // Write a program to display your information
        // when you run it , it should have this outcome
        // I am  YourName here
        // I am from batch 15
        // I am from Your city here
        // I love Java


    }


}
