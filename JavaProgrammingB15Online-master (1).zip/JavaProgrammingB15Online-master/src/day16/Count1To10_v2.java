package day16;

public class Count1To10_v2 {

    public static void main(String[] args) {

        int counter = 0;

        while (counter < 10) {

            // ++ counter -->> counter = counter + 1
            System.out.println(++counter);


        }


//            int counter = 1 ;

//        while ( counter <= 10) {
//
//            // ++ counter -->> counter = counter + 1
//           System.out.println( counter++ );
//
//
//        }

//        int counter = 0 ;
//
//        while( ++counter  <=10     ) {
//
//            System.out.println(counter);
//q
//         }


//        int counter = 0 ;
//
//        while( counter++   < 10  ){
//
//            System.out.println(counter);
//
//        }


    }

}
