package day03;

public class CharacterAndBoolean {

    public static void main(String[] args) {

//        char grade = 'A';
//        char emailSign = '@';
//        System.out.println("My score for Math is " + grade);


        boolean isLightOn = true;
        System.out.println("did you turn off the light ? : " + isLightOn);
        isLightOn = false;
        System.out.println("did you turn off the light ? : " + isLightOn);


//        boolean areYouSleeping = false ;
//        System.out.println("Are you sleeping : ? "  + areYouSleeping);

    }

}
