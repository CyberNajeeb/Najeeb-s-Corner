package day03;

public class StringDateType {


    public static void main(String[] args) {

        String name = "Akbar";
        int age = 32;
        double height = 5.11;
        char myLastNameFirstChar = 'A';
        boolean isMarried = true;
        byte childrenCount = 2;
        String city = "Tyson";


        System.out.println(name);

        System.out.println("My name is : " + name);
        System.out.println("My age is : " + age);
        System.out.println("My Last Name First Character is : " + myLastNameFirstChar);
        System.out.println("I am married : " + isMarried);
        System.out.println("I have " + childrenCount + " kids ");
        System.out.println("I live in " + city);


        // continue the rest about yourself


    }


}
