package day03;

public class EscapeCharacter {

    public static void main(String[] args) {

        System.out.println("  Hello \\ world ");

        System.out.println("I like the book \"Java\"  awesome ");

        System.out.println("The move name is : \'Lord of the rings\'  ");

        System.out.println("Hello\tWorld");

        System.out.println("Hello \n  B15");

        //  what is the equivilent of println and print , using one of the above

        System.out.print("This is regular print \n");
        System.out.println("This is println ");


    }


}
