package day03;

public class PrimitivesPractice_IntegerType {

    public static void main(String[] args) {


        byte letterCount = 26;

        System.out.println(" the letter count is  " + letterCount);

        short sheepCount = 20;
        System.out.println(" Sheep count is  " + sheepCount);

        int catCount = 2;

        System.out.println(" The cat count of in this house is  " + catCount);

        long mileToSun = 10000000L;

        System.out.println(" The millage to Sun is " + mileToSun);


        long mileToMoon = 5000000l;

        System.out.println(" The mile to Moon is " + mileToMoon);

        float priceOfBanana = 1.99f;

        System.out.println(" The price of the Banana is " + priceOfBanana);
        float priceOfPotato = 3.49f;

        System.out.println(" Price of the potato is " + priceOfPotato);

        double priceOfIpad1 = 355.99d;

        System.out.println(" Price of ipad is  " + priceOfIpad1);


        double priceOfIpadPro = 1024.99;

        System.out.println(" The price of ipadpro is " + priceOfIpadPro);
        double priceOfMac = 2299.99;

        System.out.println(" the price of mac is " + priceOfMac);

        // if you have a whole number by itself, complier aumatically assume its an int
        //


    }
}