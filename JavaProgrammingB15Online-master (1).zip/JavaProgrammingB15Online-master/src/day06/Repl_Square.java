package day06;

public class Repl_Square {

    public static void main(String[] args) {

        System.out.println("* * * * * * * *");
        System.out.println("*             *");
        System.out.println("*             *");
        System.out.println("*             *");
        System.out.println("*             *");
        System.out.println("*             *");
        System.out.println("*             *");
        System.out.println("* * * * * * * *");


    }

}
