package day06;

public class OddOrEven {

    public static void main(String[] args) {


        int myNumber = 10;
        int yourNumber = 11;

        System.out.println("myNumber Remainder of dividing by 2 : " + myNumber % 2);

        System.out.println("yourNumber Remainder of dividing by 2 : " + yourNumber % 2);

        System.out.println("adding my number to your number : " + yourNumber + myNumber);

        System.out.println("adding my number to your number : " + (yourNumber + myNumber));


    }


}
