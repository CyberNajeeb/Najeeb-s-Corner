package day52.warmup;

public interface Transferable {

    public abstract void transferAll(Account otherAccount);

    // public abstract void transferAmount(Account otherAccount , int amountToTransfer);

}
