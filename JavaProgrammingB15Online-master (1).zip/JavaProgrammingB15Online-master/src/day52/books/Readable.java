package day52.books;

public interface Readable {

    public abstract void read();

}
