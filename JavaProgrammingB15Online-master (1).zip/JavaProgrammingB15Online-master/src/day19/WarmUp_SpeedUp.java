package day19;

public class WarmUp_SpeedUp {

    public static void main(String[] args) {

        // this is how we counted from 1 to 10

//        for(int i = 1 ; i <= 10 ; i++){
//
//            System.out.print(i + " " );
//
//        }

        int start = 5;
        int end = 19;

        System.out.print("you have started at speed-->>  ");
        for (int i = start; i <= end; i++) {

            System.out.print(i + " ");

        }


    }


}
